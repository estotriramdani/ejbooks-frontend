const preloader = document.querySelector(".animasi-preloader");
setTimeout(() => {
  preloader.classList.add("hide");
}, 1500);
